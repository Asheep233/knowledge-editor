import type { MarkdownToken as TsMarkdownToken, MarkdownLexerConfiguration } from '@tiptap/core'
/**
 * 自定义 marked tokenizers（KE 扩展语法 + 数学公式）。
 * 通过扩展字段 markdownTokenizer 注入：@tiptap/markdown 的 registerExtension
 * 会自动调用 registerTokenizer，将下列 tokenizer 注册进 marked 实例。
 *
 * 契约（参考 marked 官方扩展）：
 * - start(src): 返回第一个可能匹配位置，无匹配返回 -1
 * - tokenize(src, tokens, helpers): 从 start 位置起的子串上尝试匹配，
 *   返回 { type, raw, ... } 或 undefined（undefined 时 marked 回退默认规则）
 */

export interface MarkdownToken {
  type: string
  raw: string
  [key: string]: unknown
}

/** 行内公式 $...$（排除 $$ 与转义 \$；要求 LaTeX 非空） */
export const mathInlineTokenizer = {
  name: 'math_inline',
  level: 'inline' as const,
  start: (src: string) => src.indexOf('$'),
  tokenize(src: string): MarkdownToken | undefined {
    if (!src.startsWith('$') || src.startsWith('$$')) return undefined
    const m = /^\$(?!\$)([\s\S]*?[^\\\s$])\$(?!\$)/.exec(src)
    if (!m || !m[1].trim()) return undefined
    return { type: 'math_inline', raw: m[0], latex: m[1].trim(), id: '' }
  },
}

/** 块级公式 $$...$$（独占行或单行，块级 token） */
export const mathBlockTokenizer = {
  name: 'math_block',
  level: 'block' as const,
  // 仅当 src 以 $$ 开头（独占行）时返回 0，否则 -1。
  // 关键：若返回非 0 位置，marked 会把行切开并把剩余部分交给默认 html 规则，
  // 导致行内 $ 符号等被错误消费。block 级 start 必须只在行首命中时返回 0。
  start: (src: string) => (src.startsWith('$$') ? 0 : -1),
  tokenize(src: string): MarkdownToken | undefined {
    const m = /^\$\$\n?([\s\S]*?)\n?\$\$\s*(?:\n|$)/.exec(src)
    if (!m) return undefined
    const latex = m[1].trim()
    if (!latex) return undefined
    return { type: 'math_block', raw: m[0], latex, id: '' }
  },
}

/**
 * KE 注释块 tokenizer 工厂：<!-- ke-{kind}: {json} -->（独占行）。
 * JSON 用括号平衡匹配（兼容 params 等嵌套对象），
 * 不会把后续的 ke-* 标记行吞进本 token（贪婪 [\s\S]*\} 在连续标记时会误吞）。
 */
export function keCommentTokenizer(kind: string) {
  return {
    name: `ke_${kind}`,
    level: 'block' as const,
    // 仅当 src 以 <!-- ke-{kind}: 开头（独占行）时返回 0，否则 -1。
    // 不能返回 indexOf('<!--')：那会把含行内 <!-- 的段落切开（如行内脚注标记），
    // 切开后的剩余部分会被 marked 默认 html 规则消费，inline tokenizer 永不执行。
    start: (src: string) => (new RegExp(`^<!--\\s*ke-${kind}:`).test(src) ? 0 : -1),
    tokenize(src: string): MarkdownToken | undefined {
      const startRe = new RegExp(`^<!--\\s*ke-${kind}:\\s*`)
      const m0 = startRe.exec(src)
      if (!m0) return undefined
      const bodyStart = m0[0].length
      if (src[bodyStart] !== '{') return undefined
      const jsonStr = matchBalancedJson(src, bodyStart)
      if (jsonStr === null) return undefined
      const rest = src.slice(bodyStart + jsonStr.length)
      const close = /^\s*-->\s*(?:\n|$)/.exec(rest)
      if (!close) return undefined
      let attrs: Record<string, unknown>
      try {
        attrs = JSON.parse(jsonStr) as Record<string, unknown>
      } catch {
        return undefined
      }
      if (typeof attrs !== 'object' || attrs === null) return undefined
      const raw = src.slice(0, bodyStart + jsonStr.length + close[0].length)
      return { type: `ke_${kind}`, raw, attrs }
    },
  }
}

/**
 * 信息块（note）tokenizer：支持两种格式。
 * 1) 包裹格式（新）：<!-- ke-note: {json} -->\n内容...\n<!-- /ke-note -->
 *    内容（开始标记与结束标记之间的 markdown）随 token.content 交给 parseMarkdown 解析，
 *    使信息块内容成为 PM 可编辑内容（可在块内插入脚注上标等 inline 节点）。
 * 2) 自闭合格式（旧，v0~v3）：<!-- ke-note: {json} -->（content/text 在 json attr 中）
 *    标记 selfClosed: true，由 parseMarkdown 将 content/text 迁移为文本子节点。
 */
export const keNoteTokenizer = {
  name: 'ke_note',
  level: 'block' as const,
  start: (src: string) => (/^<!--\s*ke-note:/.test(src) ? 0 : -1),
  tokenize(src: string, _tokens: TsMarkdownToken[], lexer: MarkdownLexerConfiguration): TsMarkdownToken | undefined {
    const m0 = /^<!--\s*ke-note:\s*/.exec(src)
    if (!m0) return undefined
    const bodyStart = m0[0].length
    if (src[bodyStart] !== '{') return undefined
    const jsonStr = matchBalancedJson(src, bodyStart)
    if (jsonStr === null) return undefined
    const rest = src.slice(bodyStart + jsonStr.length)
    const close = /^\s*-->\s*(?:\n|$)/.exec(rest)
    if (!close) return undefined
    let attrs: Record<string, unknown>
    try {
      attrs = JSON.parse(jsonStr) as Record<string, unknown>
    } catch {
      return undefined
    }
    if (typeof attrs !== 'object' || attrs === null) return undefined
    const headLen = bodyStart + jsonStr.length + close[0].length
    const contentSrc = src.slice(headLen)
    // R3：结束标记只在「本块范围内」有效——下一个块级 ke-* 标记行出现前。
    // 旧实现 indexOf 在文档剩余全文搜索：空信息块（旧格式无闭合标记）之后
    // 若存在任何包裹笔记的结束标记，中间所有内容（含下一个笔记的头标记）会被
    // 吞为本笔记的块内文本，下一个笔记节点被整体消灭。
    const endIdx = findNoteEnd(contentSrc)
    if (endIdx < 0) {
      // 自闭合（旧格式）：content/text 存于 attr，无块内内容
      const raw = src.slice(0, headLen)
      return { type: 'ke_note', raw, attrs, selfClosed: true }
    }
    // 包裹格式：开始标记后、结束标记前为块内内容
    let inner = contentSrc.slice(0, endIdx)
    // 去掉内容首尾的空白行，保证 parseMarkdown 解析干净
    inner = inner.replace(/^\s*\n/, '').replace(/\s+$/, '')
    const raw = src.slice(0, headLen + endIdx + NOTE_END_TAG.length)
    // v1.1.7（A）：内部 markdown 由 marked lexer 词法化 → tokens → 块级解析
    const innerTokens = lexer?.blockTokens(inner) ?? []
    return { type: 'ke_note', raw, attrs, content: inner, tokens: innerTokens }
  },
}

/** ke-note 包裹格式的闭合标记（与 NoteExtension.renderMarkdown 输出一致）。 */
const NOTE_END_TAG = '<!-- /ke-note -->'

/**
 * 在本块范围内查找闭合标记 `<!-- /ke-note -->` 的起始位置。
 * 扫描规则（R3）：按行前进；
 * - 命中本块闭合标记 → 返回其位置；
 * - 命中其他任何 ke-* 标记行（下一个信息块头标记、模块标记、闭合标记等）
 *   → 本块无闭合标记（旧格式自闭合），返回 -1；
 * - 其余内容（含公式、普通文本等）继续扫描。
 */
function findNoteEnd(contentSrc: string): number {
  let pos = 0
  while (pos < contentSrc.length) {
    const eol = contentSrc.indexOf('\n', pos)
    const lineEnd = eol === -1 ? contentSrc.length : eol
    const line = contentSrc.slice(pos, lineEnd).trim()
    if (/^<!--\s*\/\s*ke-note\s*-->$/.test(line)) return pos
    if (/^<!--\s*\/?ke-[a-zA-Z]/.test(line)) return -1
    if (eol === -1) break
    pos = eol + 1
  }
  return -1
}

/**
 * 从 src[start]（必须是 '{'）开始做括号平衡匹配，返回完整 JSON 字符串。
 * 正确处理字符串内的 { } 与转义，兼容嵌套对象/数组。
 */
function matchBalancedJson(src: string, start: number): string | null {
  let depth = 0
  let inStr = false
  let esc = false
  for (let i = start; i < src.length; i++) {
    const ch = src[i]
    if (inStr) {
      if (esc) esc = false
      else if (ch === '\\') esc = true
      else if (ch === '"') inStr = false
      continue
    }
    if (ch === '"') inStr = true
    else if (ch === '{') depth++
    else if (ch === '}') {
      depth--
      if (depth === 0) return src.slice(start, i + 1)
    }
  }
  return null
}

/** 脚注引用 inline tokenizer：<!-- ke-footnote: {json} -->（行内，渲染为上标 [n]） */
export const footnoteTokenizer = {
  name: 'ke_footnote',
  level: 'inline' as const,
  start: (src: string) => src.indexOf('<!--'),
  tokenize(src: string): MarkdownToken | undefined {
    // 非贪婪匹配到第一个 }（footnote JSON 无嵌套，单行紧凑）
    const m = /^<!--\s*ke-footnote:\s*(\{[\s\S]*?\})\s*-->/.exec(src)
    if (!m) return undefined
    let attrs: Record<string, unknown>
    try {
      attrs = JSON.parse(m[1]) as Record<string, unknown>
    } catch {
      return undefined
    }
    if (typeof attrs !== 'object' || attrs === null) return undefined
    return { type: 'ke_footnote', raw: m[0], attrs }
  },
}

/**
 * 表格 tokenizer（GFM 风格，块级）。
 * 支持带首尾 | 的标准表格；第一行必须是表头，第二行必须是分隔行（|-|-|）。
 * start 宽松（行首含 |），tokenize 严格校验，非表格行会回退给 marked 默认规则。
 */
export const tableTokenizer = {
  name: 'ke_table',
  level: 'block' as const,
  start: (src: string) => (/^[^\n]*\|/.test(src) ? 0 : -1),
  tokenize(src: string): MarkdownToken | undefined {
    const lines = src.split('\n')
    const header = parseTableRow(lines[0])
    if (!header || header.length === 0) return undefined
    const sep = parseTableRow(lines[1])
    if (!sep || sep.some((c) => !/^:?-{3,}:?$/.test(c.trim()))) return undefined
    const rows: string[][] = []
    let i = 2
    while (i < lines.length) {
      const line = lines[i]
      if (!line.trim()) break
      const r = parseTableRow(line)
      if (!r) break
      rows.push(r)
      i++
    }
    const raw = lines.slice(0, i).join('\n')
    return {
      type: 'ke_table',
      raw,
      headers: header.map((c) => c.trim()),
      rows: rows.map((r) => r.map((c) => c.trim())),
    }
  },
}

/**
 * 解析表格行：按「未转义的 |」分割列，`\|` 视为单元格内的字面量管道符（P1-4）。
 * 注意：`\|` 在解析时被还原为 `|`（文本节点内容是真正的 `|`），
 * 序列化端再统一把 `|` 转义回 `\|`，保证往返列数不变。
 */
function parseTableRow(line: string): string[] | null {
  const t = line.trim()
  if (!t.startsWith('|') || !t.endsWith('|')) return null
  const inner = t.slice(1, -1)
  const cells: string[] = []
  let cur = ''
  for (let i = 0; i < inner.length; i++) {
    const ch = inner[i]
    if (ch === '\\' && inner[i + 1] === '|') {
      cur += '|' // 还原转义的管道符
      i++
    } else if (ch === '|') {
      cells.push(cur)
      cur = ''
    } else {
      cur += ch
    }
  }
  cells.push(cur)
  return cells.map((c) => c.trim())
}

/**
 * 脚注区域 tokenizer（块级）：
 * <!-- ke-footnotes:start -->
 * <!-- ke-footnote-item: {"id":"..","n":1,"text":".."} -->
 * <!-- ke-footnotes:end -->
 *
 * 注意：block 扩展的 tokenize 会被 marked 在每个 block 循环直接调用（不先查 start），
 * 因此 tokenize 必须自行校验 src 以 start 标记开头，否则会误吞到文档任意位置的 end 标记。
 */
export const footnotesBlockTokenizer = {
  name: 'ke_footnotes',
  level: 'block' as const,
  start: (src: string) => (/^<!--\s*ke-footnotes:start\s*-->/.test(src) ? 0 : -1),
  tokenize(src: string): MarkdownToken | undefined {
    if (!/^<!--\s*ke-footnotes:start\s*-->/.test(src)) return undefined
    const endTag = '<!-- ke-footnotes:end -->'
    const endIdx = src.indexOf(endTag)
    if (endIdx < 0) return undefined
    const raw = src.slice(0, endIdx + endTag.length)
    const inner = raw.slice(raw.indexOf('-->') + 3, raw.lastIndexOf(endTag))
    const items: Array<Record<string, unknown>> = []
    // P2-17：条目文本可能包含 `}`（甚至紧跟 ` --> `）。非贪婪匹配会在文本内的 `}`
    // 处截断，导致整条脚注丢失。这里先按括号平衡匹配（正确跳过字符串内的 `}`），
    // 失败再回退非贪婪（兼容旧版不规范序列化）。
    const marker = '<!-- ke-footnote-item:'
    let pos = inner.indexOf(marker)
    while (pos >= 0) {
      const after = pos + marker.length
      const parsed = parseFootnoteItem(inner, after)
      if (parsed) {
        items.push(parsed.obj)
        pos = inner.indexOf(marker, parsed.end)
      } else {
        // 单个条目损坏：忽略该条目，但区域整体保留（其他条目不丢）
        pos = inner.indexOf(marker, after)
      }
    }
    return { type: 'ke_footnotes', raw, items }
  },
}

/**
 * 从 `<!-- ke-footnote-item:` 之后的位置解析一个脚注条目 JSON 对象。
 * 先试 matchBalancedJson（正确处理字符串内 `}` 与转义），失败再试非贪婪（旧版容错）。
 * 返回 { obj, end }（end 为条目整体结束下标，含尾部 -->），失败返回 null。
 */
function parseFootnoteItem(src: string, start: number): { obj: Record<string, unknown>; end: number } | null {
  let bodyStart = start
  while (bodyStart < src.length && /\s/.test(src[bodyStart])) bodyStart++
  if (src[bodyStart] !== '{') return null
  // 1) 括号平衡匹配：跳过字符串内的 `}`，得到完整对象
  const balanced = matchBalancedJson(src, bodyStart)
  if (balanced !== null) {
    const rest = bodyStart + balanced.length
    const close = /^\s*-->/.exec(src.slice(rest))
    if (close) {
      try {
        const obj = JSON.parse(balanced) as Record<string, unknown>
        if (obj && typeof obj === 'object') return { obj, end: rest + close[0].length }
      } catch {
        // 平衡匹配得到但 JSON 损坏：回退非贪婪
      }
    }
  }
  // 2) 旧版容错：非贪婪匹配到第一个 `} --> `（文本含裸 `}` 的不规范序列化）
  const greedy = /^\{[\s\S]*?\}\s*-->/.exec(src.slice(bodyStart))
  if (greedy) {
    try {
      const obj = JSON.parse(greedy[0].replace(/\s*-->$/, '')) as Record<string, unknown>
      if (obj && typeof obj === 'object') return { obj, end: bodyStart + greedy[0].length }
    } catch {
      return null
    }
  }
  return null
}

/**
 * 兜底 tokenizer（块级 + 行内）：保留未被具体扩展消费的 ke-* 注释原文。
 * - 命中范围：任意 `<!-- ke-...: ` 注释（含已知 kind + 未知 kind + 大小写变体）。
 * - 依赖注册顺序：@tiptap/markdown 通过 marked.use + unshift 注册 tokenizer，
 *   后注册的先执行；GenericFallback 是最先注册的，因此其 tokenizer 最后执行。
 *   于是：具体 ke-* tokenizer（keNote / keComment / footnote / footnotes）先执行，
 *   能正常解析的已知 kind 会被它们消费；只有解析失败（JSON 损坏 / 括号不匹配）
 *   的已知 kind、未知 kind 或大小写变体（ke-NOTE 等，document-format §4：
 *   「大小写不符→原样保留」）才会落到本 fallback，按原文保留。
 * - F06：块级兜底不再排除 footnote 系——独占一行的 ke-footnote 引用、
 *   未闭合 ke-footnotes 区域、孤儿 footnote-item 此前整条消失；改为原样保留
 *   （行内脚注仍由 footnoteTokenizer 在段落内消费，不受影响）。
 * - kind 允许连字符/数字/大写（如 ke-future-block、ke-x2:、ke-NOTE:），
 *   确保任意标记可保留。
 */
// 行内兜底：匹配任意 ke-* 注释（含已知 kind + footnote + 大小写变体）。
const KE_INLINE_CATCH_PATTERN = `^<!--\\s*ke-[a-zA-Z][a-zA-Z0-9-]*:`
// 块级兜底：不排除 footnote 系（F06，见上）；note/module/attach/video 等
// 块级已知 kind 仍允许命中，用于「块级已知 kind + 损坏 JSON」的兜底保留。
const KE_BLOCK_CATCH_PATTERN = `^<!--\\s*ke-[a-zA-Z][a-zA-Z0-9-]*:`

export const keFallbackTokenizer = {
  name: 'ke_fallback',
  level: 'block' as const,
  // S-2 附带修复：`start` 必须恒返回 -1（不「抢」块起点）。
  // 原实现 `start: (src) => /^<!--\s*ke-/.test(src) ? 0 : -1`：marked 的块级词法分析器
  // 用各扩展的 start() 决定「从哪里截断当前段落」。当一行是「1 个字符 + 行内脚注」时
  // （如 `一<!-- ke-footnote … -->。`——GFM 文档 `一[^1]。` 转换后正是此形态），
  // 分析器推进 1 个字符后 slice 以 `<!--` 开头 → start() 返回 0 → **段落被从第 1 个
  // 字符处截断**，该注释被当块级 fallback 消费，引用不再是行内 footnote 节点
  // （实测 `一[^x] 二[^x] 三[^x]。` 的 refs 由 3 变 2）。
  // 返回 -1 后 marked 不再据此截断；真正处于块级位置时仍会调用 tokenize()，
  // 未知 kind / 损坏 JSON / 大小写变体的 ke-* 注释原样保留能力不变
  // （fidelity-regression 的 P1-2/P1-3 全绿）。该缺陷在干净基线 HEAD c256515 上
  // 以原生 ke 方言同样可复现，属**既有缺陷**，S-2 只是让它对普通 GFM 文档可达。
  start: () => -1,
  tokenize(src: string): MarkdownToken | undefined {
    // F06：行首的 ke-footnote 引用可能是「段首行内脚注」（编辑器可产出：
    // 光标置于段首插入脚注后，注释后紧跟正文）。若注释后同一行仍有内容，
    // 让位给段落规则 + inline tokenizer（正规脚注解析为 footnote 节点）；
    // 仅当注释独占一行（其后只有空白/行尾）时才作为块级 fallback 原样保留。
    // 其余 case（已知块级 kind 损坏 JSON / 未知 kind / 大小写变体）照旧保留。
    const m0 = new RegExp(KE_BLOCK_CATCH_PATTERN).exec(src)
    if (!m0) return undefined
    const after = src.slice(m0[0].length)
    const commentEnd = after.indexOf('-->')
    if (commentEnd >= 0) {
      const lineTail = after.slice(commentEnd + 3).split('\n')[0].trim()
      if (lineTail !== '') {
        // S-2 附带修复：行首且同行有正文的 ke-footnote，必须**在此处产出 footnote 节点**。
        // 机制：行首 `<!-- … -->` 在 marked 里是**块级 HTML**（CommonMark type-2 注释），
        // 块级规则先于行内规则生效，行内 footnoteTokenizer 拿不到机会。
        //   · 原实现返回仅含注释的 ke_fallback 块 → 引用退化为纯文本（footnoteRefs=0，
        //     正文还多出前导空格；`[^1][^2] 开头。` 产生 2 个 fallback 块）。
        //   · 若改为让位（return undefined）→ marked 把注释当 HTML 块消费，
        //     而 tiptap 无对应节点 → **注释被静默丢弃**（实测更糟）。
        // 故：可解析时直接产出 `ke_footnote` token（复用 FootnoteExtension.parseMarkdown）；
        // 损坏 JSON / 非 footnote kind 仍走原样保留，绝不丢内容。
        // 该行为缺陷在干净基线 HEAD c256515 用原生 ke 方言即可复现（既有缺陷），
        // S-2 只是让普通 GFM 文档可达该形态。
        const commentText = src.slice(0, m0[0].length + commentEnd + 3)
        const fm = /^<!--\s*ke-footnote:\s*(\{[\s\S]*?\})\s*-->$/.exec(commentText)
        if (fm) {
          try {
            const attrs = JSON.parse(fm[1]) as Record<string, unknown>
            if (attrs && typeof attrs === 'object') {
              return { type: 'ke_footnote', raw: commentText, attrs }
            }
          } catch {
            /* 损坏 JSON：落到下方原样保留 */
          }
        }
        return { type: 'ke_fallback', raw: commentText }
      }
    }
    // 非贪婪匹配到行尾的 -->（独占行）。已知块级 kind 已由各自 tokenizer 消费，
    // 能走到这里说明 kind 未知或 JSON 损坏：保留原始文本。
    const m = new RegExp(`${KE_BLOCK_CATCH_PATTERN}[\\s\\S]*?-->\\s*(?:\\n|$)`).exec(src)
    if (!m) return undefined
    return { type: 'ke_fallback', raw: m[0].replace(/\s*$/, '') }
  },
}

/** 通用 fallback（行内）：行内出现的未知 ke-* 注释保留原样 */
export const keFallbackInlineTokenizer = {
  name: 'ke_fallback_inline',
  level: 'inline' as const,
  start: (src: string) => src.indexOf('<!--'),
  tokenize(src: string): MarkdownToken | undefined {
    // 非贪婪匹配到第一个 -->。行内已知 kind（ke-footnote）由具体 tokenizer 先执行，
    // 能走到这里说明是未知 kind 或已知 kind + 损坏 JSON：按原文保留。
    const m = new RegExp(`${KE_INLINE_CATCH_PATTERN}[\\s\\S]*?-->`).exec(src)
    if (!m) return undefined
    return { type: 'ke_fallback_inline', raw: m[0] }
  },
}

/**
 * 普通 HTML 保真 tokenizer（P1-2）：
 * 保留不被任何扩展消费的「普通 HTML 注释」`<!-- ... -->`（非 ke-* 命名空间）与
 * 「HTML 块」（如 `<div class="x">内容</div>`）。这些默认被 marked 归为 html token，
 * 随后被 DOMParser 丢弃（注释整体丢失，块仅保留文本）。
 * 这里注册为块级/行内 tokenizer，命中后按 raw 原样保留。
 */

/** 行内格式化标签（这些在块级出现时由 marked 正常按段落/行内处理，不做块级保真） */
const HTML_INLINE_TAGS = new Set([
  'em', 'strong', 'b', 'i', 'u', 'a', 'code', 'span', 'br', 'img', 'del', 'ins',
  'mark', 'small', 'sub', 'sup', 'kbd', 's', 'abbr', 'cite', 'q', 'samp', 'var', 'time', 'wbr',
])

function isPlainHtmlComment(src: string): boolean {
  // F03：ke- 前缀判定大小写不敏感——`ke-NOTE` 等大小写变体不被当作普通注释
  // 转 html 保真路径，而是统一落入 GenericFallback 按原文保留。
  return /^<!--/.test(src) && !/^<!--\s*ke-/i.test(src)
}

/** 块级 HTML：注释或块级元素（tag 非行内格式化标签、非 ke-*）。 */
export const htmlPassthroughBlockTokenizer = {
  name: 'html_passthrough',
  level: 'block' as const,
  start: (src: string) => {
    if (isPlainHtmlComment(src)) return 0
    if (/^<[a-zA-Z]/.test(src)) {
      const tag = (/^<([a-zA-Z][a-zA-Z0-9-]*)/.exec(src) ?? [])[1]
      if (tag && !HTML_INLINE_TAGS.has(tag.toLowerCase())) return 0
    }
    return -1
  },
  tokenize(src: string): MarkdownToken | undefined {
    if (isPlainHtmlComment(src)) {
      const m = /^<!--[\s\S]*?-->\s*(?:\n|$)/.exec(src)
      if (!m) return undefined
      return { type: 'html_passthrough', raw: m[0].replace(/\s*$/, '') }
    }
    const openRaw = matchHtmlTag(src)
    if (!openRaw) return undefined
    const open = /^<([a-zA-Z][a-zA-Z0-9-]*)/.exec(openRaw)
    if (!open) return undefined
    const tag = open[1].toLowerCase()
    if (HTML_INLINE_TAGS.has(tag)) return undefined
    // 同一标签的匹配结束标签；若无闭合（跨块）则退化为整行。
    const closeRe = new RegExp(`</${open[1]}>`)
    const endTag = closeRe.exec(src)
    if (endTag) {
      const raw = src.slice(0, endTag.index + endTag[0].length)
      return { type: 'html_passthrough', raw }
    }
    // 无闭合标签：仅保留整行（到行尾）
    const line = /^<[a-zA-Z][^>]*>[^\n]*\n?/.exec(src)
    if (!line) return undefined
    return { type: 'html_passthrough', raw: line[0].replace(/\s*$/, '') }
  },
}

/**
 * 行内 HTML / 实体候选起点（F-2/F-3）：`<` 与 `&` 的最早出现位置。
 *
 * 性能：这里**只用 indexOf**（两次线性扫描，常数极小）。不能用 `String.search` 跑完整
 * 正则 —— 该函数会被 marked 在每次行内 tokenize 尝试时调用，正则全量扫描会让大文档
 * （2000 脚注级）变成 O(n²)（实测性能门用例可复现）。精确匹配交给 `tokenize` 的 `^` 锚定正则。
 */
function indexOfInlineHtmlCandidate(src: string): number {
  const lt = src.indexOf('<')
  const amp = src.indexOf('&')
  if (lt < 0) return amp
  if (amp < 0) return lt
  return Math.min(lt, amp)
}

/**
 * 由 marked / 既有扩展**正常转换**的行内标签：这些**不做** raw 保真
 * （否则会抢走 `*斜体*` / `[链接](url)` / 硬换行 等既有行为，破坏 `fidelity-regression` 的 P1-2 契约）。
 * 其余标签（`span`/`mark`/`kbd`/`img`/自定义标签…）marked 会丢弃 → 必须原样保留。
 */
const MARKDOWN_HANDLED_INLINE_TAGS = new Set([
  'em', 'strong', 'b', 'i', 'a', 'code', 'del', 'ins', 's', 'br',
])

/**
 * 「未知但标准」的行内标签（D-2）：marked 不转换、schema 无对应节点 → 必须按 `raw` 保真。
 * 独立出现时由下方行内 tokenizer 直接接管。
 */
export const HTML_PASSTHROUGH_INLINE_TAGS = [
  'span', 'u', 'img', 'mark', 'small', 'sub', 'sup', 'kbd', 'abbr', 'cite', 'q', 'samp', 'var', 'time', 'wbr',
] as const

/** 标准标签 → marked 原生 token 类型（D-2：仅当其内部含未知标签时由我们整体接管） */
const STANDARD_WRAPPER_TOKEN: Record<string, string> = {
  em: 'em',
  i: 'em',
  strong: 'strong',
  b: 'strong',
  del: 'del',
  s: 'del',
  ins: 'del',
  a: 'link',
  code: 'codespan',
}

/** 片段内是否含需要保真的「未知但标准」标签（`<span>`/`<mark>`…，非 markdown 标准标签） */
function hasUnknownInlineTag(inner: string): boolean {
  const re = /<([a-zA-Z][a-zA-Z0-9-]*)/g
  let m: RegExpExecArray | null
  while ((m = re.exec(inner)) !== null) {
    if (!MARKDOWN_HANDLED_INLINE_TAGS.has(m[1].toLowerCase())) return true
  }
  return false
}

/** token 列表中是否存在可承载 mark 的文本内容（递归看嵌套 tokens） */
function hasRenderableText(tokens: Array<{ type?: string; text?: unknown; tokens?: unknown }>): boolean {
  return tokens.some((t) => {
    if (t.type === 'text' || t.type === 'codespan') return String(t.text ?? '').length > 0
    return Array.isArray(t.tokens)
      ? hasRenderableText(t.tokens as Array<{ type?: string; text?: unknown; tokens?: unknown }>)
      : false
  })
}

/**
 * D-2：标准标签内部含未知标签时**整体接管**，返回 marked 原生 token（`em`/`strong`/`del`/`link`/`codespan`），
 * 其 `tokens` 由 lexer 递归词法化 → 内层未知标签照常走本 tokenizer 保真，外层标准标签仍走标准转换。
 *
 * 为什么必须接管：@tiptap/markdown 的 `parseInlineTokens` 遇到 `<em>` 这类 html token 会向后找到
 * 对应闭合标签，把**中间所有 token 原文拼接**后交给 DOMParser；未知内层标签在 schema 里没有规则
 * → 被整段丢弃（`<em><span>x</span></em>` → `*x*`）。纯标准标签（内部无未知标签）**不接管**，
 * 保持既有行为（`<em>x</em>` → `*x*`）。
 *
 * @returns token 或 undefined（= 不接管，交回既有路径）
 */
function claimStandardWrapper(
  src: string,
  openTag: string,
  name: string,
  lexer?: MarkdownLexerConfiguration,
): MarkdownToken | undefined {
  const tokenType = STANDARD_WRAPPER_TOKEN[name]
  if (!tokenType) return undefined
  const rawName = /^<([a-zA-Z][a-zA-Z0-9-]*)/.exec(openTag)?.[1]
  if (!rawName) return undefined
  const rest = src.slice(openTag.length)
  const close = new RegExp(`</${rawName}\\s*>`, 'i').exec(rest)
  if (!close) return undefined
  const inner = rest.slice(0, close.index)
  if (!hasUnknownInlineTag(inner)) return undefined
  const whole = src.slice(0, openTag.length + close.index + close[0].length)
  if (tokenType === 'codespan') {
    // `<code>` 内部按字面文本处理（HTML 语义即如此）
    return { type: 'codespan', raw: whole, text: inner }
  }
  if (!lexer?.inlineTokens) return undefined
  const tokens = lexer.inlineTokens(inner)
  // 内部没有可承载 mark 的文本（如 `<em><img …></em>` 纯原子内容）：markdown 序列化不会为
  // 非文本节点补 mark 定界符 → 外层转换会把内层内容整体吞掉。此时整体按 raw 保真（内容优先）。
  if (!hasRenderableText(tokens)) return { type: 'html_passthrough_inline', raw: whole }
  if (tokenType === 'link') {
    const hrefMatch = /\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(openTag)
    return {
      type: 'link',
      raw: whole,
      href: hrefMatch?.[1] ?? hrefMatch?.[2] ?? hrefMatch?.[3] ?? '',
      tokens,
    }
  }
  return { type: tokenType, raw: whole, tokens }
}

/**
 * 引号感知的标签扫描（F-2 修正，2026-09-18）：
 * 找结束 `>` 时**跳过** `"…"` / `'…'` 内部 —— 否则 `<span title="a>b">` 会在属性里
 * 提前截断，把剩下的 `b">` 当文本转义成 `&gt;`（实测把标签写成非法 HTML）。
 * 返回完整标签原文；不合法/超长 → null（交回 marked 的常规处理）。
 */
const MAX_TAG_LEN = 500
function matchHtmlTag(src: string): string | null {
  const m = /^<(\/?)([a-zA-Z][a-zA-Z0-9-]*)/.exec(src)
  if (!m) return null
  let i = m[0].length
  let quote: string | null = null
  for (; i < src.length && i <= MAX_TAG_LEN; i++) {
    const c = src[i]
    if (quote) {
      if (c === quote) quote = null
      continue
    }
    if (c === '"' || c === "'") {
      quote = c
      continue
    }
    if (c === '>') return src.slice(0, i + 1)
    if (c === '<') return null
  }
  return null
}
/** HTML 实体：命名 / 十进制 / 十六进制 */
const HTML_ENTITY_RE = /^&(?:#\d{1,7}|#[xX][0-9a-fA-F]{1,6}|[a-zA-Z][a-zA-Z0-9]{1,31});/

/**
 * 行内 HTML 保真（P1-2 扩展，F-2/F-3）：段落中的普通 HTML **标签**与 **HTML 实体**原样保留
 * （作为原子行内节点，序列化时逐字节输出 raw）。
 *
 * 为什么必须做：此前只覆盖注释 —— `<span style="…">红</span>` 的标签被 DOMParser 丢弃
 * （只剩文本）、`&copy;` 被序列化器二次转义成 `&amp;copy;`（实测矩阵 F-2/F-3）。
 * 标签与实体拆成独立原子（而非整段吞成一块）是为了**保持中间文本可编辑**。
 *
 * 安全边界：只匹配 `<` 紧跟字母（`a < b` 不受影响）与合法实体形状（`?a=1&b=2` 不误匹配）。
 */
export const htmlPassthroughInlineTokenizer = {
  name: 'html_passthrough_inline',
  level: 'inline' as const,
  start: (src: string) => indexOfInlineHtmlCandidate(src),
  tokenize(
    src: string,
    _tokens?: TsMarkdownToken[],
    lexer?: MarkdownLexerConfiguration,
  ): MarkdownToken | undefined {
    if (isPlainHtmlComment(src)) {
      const m = /^<!--[\s\S]*?-->/.exec(src)
      if (!m) return undefined
      return { type: 'html_passthrough_inline', raw: m[0] }
    }
    const tag = matchHtmlTag(src)
    if (tag) {
      const name = /^<\/?([a-zA-Z][a-zA-Z0-9-]*)/.exec(tag)?.[1]?.toLowerCase() ?? ''
      if (MARKDOWN_HANDLED_INLINE_TAGS.has(name)) {
        // D-2：标准标签内部含未知标签 → 整体接管（否则内层会被 DOMParser 丢弃）
        return claimStandardWrapper(src, tag, name, lexer)
      }
      return { type: 'html_passthrough_inline', raw: tag }
    }
    const entity = HTML_ENTITY_RE.exec(src)
    if (entity) return { type: 'html_passthrough_inline', raw: entity[0] }
    return undefined
  },
}
