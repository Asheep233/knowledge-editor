/**
 * 编辑器组装（约束 1：结构化 Document Model，HTML 不作为主要数据格式）。
 *
 * 数据流：
 *   Markdown 文本 ──(marked tokenizer)──▶ ProseMirror JSON（Document Model）
 *   ProseMirror JSON ──(editor.getMarkdown)──▶ Markdown 文本
 *
 * 编辑器内部始终操作 ProseMirror Document Model（Tiptap Schema 定义），
 * Markdown 仅作为存储/交换格式，由 @tiptap/markdown 双向转换。
 */
import { useEditor, type Editor } from '@tiptap/react'
import { Extension } from '@tiptap/core'
import type { JSONContent } from '@tiptap/core'
import StarterKit from '@tiptap/starter-kit'
import { Markdown } from '@tiptap/markdown'
import { history } from '@tiptap/pm/history'
import { EditorState, TextSelection } from '@tiptap/pm/state'
import Placeholder from '@tiptap/extension-placeholder'
import { OrderedListParenExtension, KeListItem } from './extensions/ListExtension'
import { KeBlockquote, KeDocument } from './extensions/KeBlockJoin'
// F-1（v1.2.0-pre.1）：任务列表 `- [x]` / `- [ ]` 往返保真。Tiptap v3 自带
// parseMarkdown/renderMarkdown（`- [x] ` 前缀），此前未注册 → 复选框状态被吞成 `- 完成`。
import { TaskItem, TaskList } from '@tiptap/extension-list'
import { MathExtension } from './extensions/MathExtension'
import { MathBlockExtension } from './extensions/MathBlockExtension'
import { NoteExtension } from './extensions/NoteExtension'
import { ModuleExtension } from './extensions/ModuleExtension'
import { AttachmentExtension } from './extensions/AttachmentExtension'
import { VideoExtension } from './extensions/VideoExtension'
import { FootnoteExtension } from './extensions/FootnoteExtension'
import { FootnotesExtension } from './extensions/FootnotesExtension'
import {
  TableMarkdownExtension,
  TableRow,
  TableCell,
  TableHeader,
} from './extensions/TableMarkdownExtension'
import { GenericFallbackExtension, GenericFallbackInlineExtension } from './extensions/GenericFallbackExtension'
import { HtmlPassthroughExtension, HtmlPassthroughInlineExtension } from './extensions/HtmlPassthroughExtension'
import { ImageMarkdownExtension } from './extensions/ImageMarkdownExtension'
import { normalizeGfmFootnotes } from './gfm-footnote'
import { uploadAttachment } from '../api/client'
import { attachmentNode, isRealFile } from './upload'

/** 自定义命令的 TS 类型声明（运行时命令由各扩展 addCommands 提供） */
declare module '@tiptap/core' {
  interface Commands<ReturnType> {
    math: {
      insertMath: (latex?: string) => ReturnType
      insertMathBlock: (latex?: string) => ReturnType
    }
    note: {
      insertNote: (text?: string, color?: string, title?: string) => ReturnType
    }
    footnote: {
      insertFootnote: (text: string) => ReturnType
      insertPlainFootnote: (text: string) => ReturnType
    }
  }
}

export interface KeEditorOptions {
  /** 初始 Markdown 内容（加载时解析进 Document Model） */
  content: string
  /** 内容变更回调（Phase 6.4：不携带序列化结果——击键时不做全量
   * 序列化，保存时由调用方现场 editor.getMarkdown()，避免大文档输入延迟） */
  onUpdate: () => void
  editable?: boolean
}

/** 快捷键（v1.1.6 三5）：Ctrl/⌘+N = 插入行内公式；Ctrl/⌘+M = 插入公式块。
 * 在编辑器层注册（任意焦点态可用）；与浏览器默认（新窗口/静音）不冲突的桌面场景优先。 */
const MathShortcuts = Extension.create({
  name: 'mathShortcuts',
  addKeyboardShortcuts() {
    return {
      // v1.1.7：有选区时**不吞文本**——折叠到选区末尾再插入（选中一段文字按 Ctrl+N 不再删除原文）
      'Mod-n': () => {
        const id = crypto.randomUUID?.() ?? `m${Date.now()}`
        this.editor
          .chain()
          .focus()
          .command(({ tr }) => {
            if (!tr.selection.empty) tr.setSelection(TextSelection.create(tr.doc, tr.selection.to))
            return true
          })
          .insertContent({ type: 'math', attrs: { id, latex: '' } })
          .run()
        openMathEditorById(this.editor, id)
        return true
      },
      'Mod-m': () => {
        const id = crypto.randomUUID?.() ?? `m${Date.now()}`
        this.editor
          .chain()
          .focus()
          .command(({ tr }) => {
            if (!tr.selection.empty) tr.setSelection(TextSelection.create(tr.doc, tr.selection.to))
            return true
          })
          .insertContent({ type: 'mathBlock', attrs: { id, latex: '' } })
          .run()
        openMathEditorById(this.editor, id)
        return true
      },
    }
  },
})


/**
 * v1.1.7：插入公式后按节点 id 定位并请求全屏编辑（替代「空节点自动弹窗」——
 * 后者会在 Ctrl+Z 撤销回空内容时误弹）。
 */
export function openMathEditorById(editor: Editor, id: string): void {
  if (!id) return
  window.setTimeout(() => {
    let found: { pos: number; nodeSize: number; latex: string; isBlock: boolean } | null = null
    editor.state.doc.descendants((node, pos) => {
      if (found) return false
      if ((node.type.name === 'math' || node.type.name === 'mathBlock') && node.attrs.id === id) {
        found = { pos, nodeSize: node.nodeSize, latex: (node.attrs.latex as string) ?? '', isBlock: node.type.name === 'mathBlock' }
        return false
      }
      return true
    })
    if (found) {
      const f = found as { pos: number; nodeSize: number; latex: string; isBlock: boolean }
      window.dispatchEvent(
        new CustomEvent('ke:math-edit-request', {
          detail: { pos: f.pos, nodeSize: f.nodeSize, id, latex: f.latex, isBlock: f.isBlock },
        }),
      )
    }
  }, 0)
}

export function useKeEditor({ content, onUpdate, editable = true }: KeEditorOptions) {
  const ed = useEditor({
    extensions: [
      StarterKit.configure({
        orderedList: false,
        listItem: false,
        // D-1/ADD-3：Document / Blockquote 的块间隔需要在「相邻混排列表」处收紧为单换行
        // （任务项与普通项是不同类型节点）→ 关闭内置实现，改用 KeDocument / KeBlockquote。
        document: false,
        blockquote: false,
        link: {
          openOnClick: false,
          autolink: true,
          HTMLAttributes: { rel: 'noopener noreferrer', target: '_blank' },
        },
        // footnotes 是非 textblock 的块级节点，固定位于文档末尾。
        // trailingNode 默认会在末尾补一个空段落（视觉上"自动换行"），
        // 把 footnotes 加入 notAfter 避免该行为。
        trailingNode: {
          node: 'paragraph',
          notAfter: ['paragraph', 'footnotes'],
        },
        // 注：StarterKit v3 不含 image 扩展，图片由 ImageMarkdownExtension 提供
        // （补标准 ![]() 的双向转换）。
      }),
      // D-1（混排列表紧凑）+ ADD-3（引用块内同族）：接管 Document / Blockquote 的块间隔
      KeDocument,
      KeBlockquote,
      // 普通 HTML 保真（P1-2）：注释 / HTML 块原样保留。放在最前（最后执行），
      // 且只命中非 ke-* 的注释与块级元素，不会抢占具体 ke-* tokenizer。
      HtmlPassthroughExtension,
      HtmlPassthroughInlineExtension,
      // 兜底必须先注册（@tiptap/markdown 用 marked.use + unshift 注册 tokenizer：
      // 后注册的先执行）。因此 fallback 放在最前，确保具体 ke-* tokenizer 先执行，
      // fallback 只兜底未知 kind 与损坏 JSON 的已知 kind。
      GenericFallbackExtension,
      GenericFallbackInlineExtension,
      // v1.1.5 ⑥：输入规则支持 `1. ` / `1) `（Obsidian 式），序列化仍输出规范的 `1. `
      OrderedListParenExtension,
      // v1.1.5 ⑥ 补：空列表项 Enter = 继续列表（Obsidian 式），第二次回车退出
      KeListItem,
      // F-1：任务列表（`- [x] 完成` → taskItem(checked) → 原样输出 `- [x] 完成`）
      TaskList,
      TaskItem,
      // v1.1.6 三5：Ctrl+N / Ctrl+M 插入公式
      MathShortcuts,
      // 标准 Markdown 图片：![alt](src)
      ImageMarkdownExtension,
      // KE 扩展节点（math / mathBlock / note / module / attach / video / footnote）
      MathExtension,
      MathBlockExtension,
      NoteExtension,
      ModuleExtension,
      AttachmentExtension,
      VideoExtension,
      FootnoteExtension,
      // Phase 3：脚注独立块级节点（footnotes）+ 表格（GFM 往返）
      FootnotesExtension,
      TableMarkdownExtension,
      TableRow,
      TableCell,
      TableHeader,
      // 空文档占位提示：直接点击正文输入（正文字体）
      Placeholder.configure({
        placeholder: '开始输入正文…（Markdown 可用：# 标题、$公式$、- 列表）',
        emptyEditorClass: 'is-editor-empty',
      }),
      // Markdown 序列化/解析：Markdown 作为存储格式
      Markdown.configure({
        indentation: { style: 'space', size: 2 },
      }),
    ],
    content,
    contentType: 'markdown', // 字符串内容按 Markdown 解析进 Document Model
    editable,
    onUpdate: () => onUpdate(),
    editorProps: {
      attributes: {
        class: 'ke-editor-prose',
      },
      // 拖拽添加附件（v0.6.1）：拦截 ProseMirror 对拖入图片的默认
      // base64 内联行为，改为上传后插入 attach/video 节点。必须在此层
      // 处理——PM 的原生 drop 监听先于 React 容器事件执行，容器层
      // onDrop 无法阻止默认插入。
      // v1.1.7 修复：剪贴板图片/文件（截图 Ctrl+V、复制文件）→ 上传 + 插入附件节点。
      // 原实现只处理 drop，粘贴图片走浏览器默认（被 CSP/PM 丢弃），表现为「粘贴完全无效」。
      handlePaste: (view, event) => {
        const dt = event.clipboardData
        if (!dt) return false
        const files: File[] = []
        for (const item of Array.from(dt.items ?? [])) {
          if (item.kind === 'file') {
            const f = item.getAsFile()
            if (f) files.push(f)
          }
        }
        if (files.length === 0) {
          for (const f of Array.from(dt.files ?? [])) files.push(f)
        }
        const real = files.filter(isRealFile)
        if (real.length === 0) return false
        event.preventDefault()
        const pos = view.state.selection.from
        void (async () => {
          for (const f of real) {
            try {
              const res = await uploadAttachment(f)
              const node = attachmentNode(view.state.schema, res, f.name)
              view.dispatch(view.state.tr.insert(pos, node).scrollIntoView())
            } catch (err) {
              window.alert(`附件上传失败：${String(err)}`)
            }
          }
        })()
        return true
      },
      handleDrop: (view, event) => {
        const files = event.dataTransfer?.files
        if (!files || files.length === 0) return false
        const real = Array.from(files).filter(isRealFile)
        if (real.length === 0) return false
        event.preventDefault()
        const pos =
          view.posAtCoords({ left: event.clientX, top: event.clientY })?.pos ??
          view.state.selection.from
        void (async () => {
          for (const f of real) {
            try {
              const res = await uploadAttachment(f)
              const node = attachmentNode(view.state.schema, res, f.name)
              view.dispatch(view.state.tr.insert(pos, node).scrollIntoView())
            } catch (err) {
              window.alert(`附件上传失败：${String(err)}`)
            }
          }
        })()
        return true
      },
    },
  })
  return ed}

/** `Branch.empty` 为 prosemirror-history 的模块级常量，只需捕获一次即可复用。 */
let emptyHistoryBranch: unknown

/**
 * 清空 undo/redo 历史栈（P0-4）。
 * `setContent` 的重置交易默认进入 undo 栈，导致切换文档后 Ctrl+Z 把上一文档内容
 * 灌进当前文档。这里通过向 history 插件注入一份「空历史状态」元数据，把 undo/redo
 * 栈一并清空（后续用户输入仍会正常记录）。
 */
function clearUndoRedoHistory(editor: Editor): void {
  const histPlugin = editor.state.plugins.find((p) => {
    const s = p.getState(editor.state) as Record<string, unknown> | undefined
    return !!s && typeof s === 'object' && 'done' in s && 'undone' in s && 'prevTime' in s
  })
  if (!histPlugin) return
  if (emptyHistoryBranch === undefined) {
    // 用一个临时状态实例读取 history 插件的初始状态，拿到规整的 `Branch.empty`。
    const temp = EditorState.create({ schema: editor.schema, plugins: [history()] })
    emptyHistoryBranch = temp.plugins[0].getState(temp)?.done
  }
  if (emptyHistoryBranch === undefined) return
  // 0-step 交易：仅重写 history 插件状态，不改动文档，不会触发 update 事件。
  const tr = editor.state.tr
  // histPlugin.key 是 history 插件的 PluginKey，向交易写入其历史状态元数据即可重置 undo/redo 栈。
  const historyKey = (histPlugin as unknown as { key: unknown }).key
  tr.setMeta(historyKey as never, {
    historyState: {
      done: emptyHistoryBranch,
      undone: emptyHistoryBranch,
      prevRanges: null,
      prevTime: 0,
      prevComposition: -1,
    },
  })
  editor.view.dispatch(tr)
}

/**
 * 会话级「Markdown → Document Model JSON」解析缓存（P3-2 缓解）。
 *
 * 实测定位：@tiptap/markdown（v3.29.x）的 markdown→PM JSON 链路存在超线性
 * 复杂度（256KB≈4.4s / 512KB≈29s；同内容等价 HTML 路径仅 280ms；纯 marked
 * 解析 21ms——瓶颈在上游 MarkdownManager 的 token→generateJSON 环节，
 * 与 KE 自定义 tokenizer 无直接关系，无法在本仓库线性化修复）。
 * 本缓存使「重开最近打开过的文档」由秒级回到亚秒级（JSON 路径近似线性），
 * 首次打开大文档仍受上游上限约束（见 docs/perf-notes P3-2 记录）。
 */
const mdDocCache = new Map<string, JSONContent>()
const MD_CACHE_MAX = 16

/** 文档切换时重新载入 Markdown 内容。
 * - P0-4：加载后清空 undo/redo 历史，避免 Ctrl+Z 跨文档串内容；
 * - P1-1：`emitUpdate: false` 抑制加载触发的 update（「打开文档即保存」消失）；
 * - P3-2：命中会话缓存时走 JSON 快速路径（复制后 setContent，避免二次解析）。 */
export function setKeContent(editor: Editor, markdown: string): void {
  const cached = mdDocCache.get(markdown)
  if (cached) {
    editor.commands.setContent(JSON.parse(JSON.stringify(cached)) as JSONContent, {
      contentType: 'json',
      emitUpdate: false,
    })
  } else {
    // S-2：解析前把 GFM 脚注语法规范化为 ke 方言（规范 document-format.md §2.3.1）。
    // 生产环境 markdown 解析入口仅此一处；无脚注定义时函数原样返回（零行为变化）。
    // 缓存仍以**原始 markdown** 为键，故重复打开同一文件命中缓存。
    editor.commands.setContent(normalizeGfmFootnotes(markdown), { contentType: 'markdown', emitUpdate: false })
    mdDocCache.set(markdown, editor.getJSON())
    if (mdDocCache.size > MD_CACHE_MAX) {
      const oldest = mdDocCache.keys().next().value
      if (oldest !== undefined) mdDocCache.delete(oldest)
    }
  }
  clearUndoRedoHistory(editor)
}

/** 测试钩子：清空解析缓存。 */
export function clearMdDocCache(): void {
  mdDocCache.clear()
}
