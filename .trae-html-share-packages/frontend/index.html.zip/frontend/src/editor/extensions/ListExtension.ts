/**
 * 列表扩展（v1.1.5 ⑥）。
 *
 * 1) OrderedListParenExtension：输入规则支持 `1. ` / `1) `（Obsidian 式）；
 *    默认 Tiptap 输入规则只认 `1. `（硬编码 orderedListInputRegex = /^(\d+)\.\s$/），
 *    `1) ` 不转换 → 两行混排（列表 + 纯文本）→ `)` 视觉不对齐。
 *    序列化输出仍为规范化的 `1. `（连续、无空行、渲染对齐）。
 *
 * 2) KeListItem：空列表项 Enter 行为（Obsidian 式）。
 *    Tiptap 默认：空列表项 Enter = 退出列表——用户输入 `1. `（转换后项为空）
 *    立即回车 → 列表"被删掉"。改为：空项 Enter → 继续列表（生成下一项）；
 *    新项仍空再 Enter → 退出列表（回到段落）；非空项 Enter → 正常 split。
 */
import { OrderedList } from '@tiptap/extension-list'
import { ListItem } from '@tiptap/extension-list'
import { getExtensionField, wrappingInputRule } from '@tiptap/core'

const LIST_INPUT_RE = /^(\d+)[.)]\s$/

/**
 * ADD-2（GFM 有序列表任务项）：`1. [x] a` 的文本 `[x] a` 会被通用转义成 `\[x\] a`
 * （为防误判链接语法），导致复选框状态变成字面反斜杠文本。
 * 这里只还原**列表标记之后**的复选框标记（行首锚定、含缩进），其余文本转义一律不变。
 */
const ORDERED_TASK_MARKER_RE = /^([ \t]*(?:\d+[.)]\s+))\\\[([ xX])\\\](?=\s|$)/gm

export const OrderedListParenExtension = OrderedList.extend({
  addInputRules() {
    const joinPredicate = (match: RegExpMatchArray, node: { attrs: { type?: string | null }; childCount: number; attrsStart?: number }) => {
      const hasDefaultType = !node.attrs.type || node.attrs.type === '1'
      const start = (node.attrs as { start?: number }).start ?? 1
      return hasDefaultType && node.childCount + start === Number(match[1])
    }
    const rule = wrappingInputRule({
      find: LIST_INPUT_RE,
      type: this.type,
      getAttributes: (match) => ({ start: Number(match[1]) }),
      joinPredicate,
    })
    return [rule]
  },

  renderMarkdown(node, helpers, ctx) {
    const base = getExtensionField<(n: unknown, h: unknown, c: unknown) => string>(OrderedList, 'renderMarkdown')
    const out = base ? base(node, helpers, ctx) : ''
    return out.replace(ORDERED_TASK_MARKER_RE, '$1[$2]')
  },
})

export const KeListItem = ListItem.extend({
  // 高优先级：确保 Enter 行为对列表项生效（默认同优先级时按键可能被 StarterKit 系抢先）
  priority: 1000,
  addKeyboardShortcuts() {
    return {
      Enter: () => {
        const ed = this.editor
        const { $from } = ed.state.selection
        let li: ReturnType<typeof $from.node> | null = null
        for (let d = $from.depth; d > 0; d--) {
          if ($from.node(d).type.name === 'listItem') {
            li = $from.node(d)
            break
          }
        }
        if (!li) return false
        // 判空必须看**结构**，不能看 textContent：行内公式/图片等 atom 节点的 textContent 是空串，
        // 于是「只含一个公式的列表项」会被误判为空项 → Enter 直接把该项提出列表。
        // 用户实测：`2. $J(A,L(A))=L(A)∩U(L(A))$` 上按 Enter → 第 2 项变成列表外的段落。
        const first = li.firstChild
        const isEmpty =
          li.childCount === 1 &&
          first !== null &&
          first.type.name === 'paragraph' &&
          first.content.size === 0
        if (isEmpty) {
          // task-51：空项 Enter → **干净退出列表**（主流编辑器行为，也是用户期望）。
          // 不再使用模块级 `continuationEmpty`（不来自文档状态 → 跨文档/跨会话残留 → 行为不可预测）；
          // 也不走 `splitListItem`（它对真空项会内部转 lift，是「删列表根」的历史根因）。
          // 该路径不依赖任何历史状态：同一输入 → 同一结果。
          return ed.commands.liftListItem('listItem')
        }
        return ed.commands.splitListItem('listItem')
      },
    }
  },
})

export default OrderedListParenExtension
